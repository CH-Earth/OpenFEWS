import xarray as xr
import numpy as np
import logging
import sys


def setup_logging(log_file: str) -> None:
    """Configure logging to console and a user‑specified file."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )


def convert_netcdf_format(input_file: str, output_file: str, drainage_db_file: str) -> None:
    """Convert FEWS point‑timeseries NetCDF to MESH forcing format.

    * Re‑orders the *subbasin* dimension using `Rank` from the drainage database.
    * Drops unnecessary variables and attributes.
    * Ensures data variables have dimensions `(subbasin, time)`.
    * Sets proper `_FillValue`, units and CRS information expected by MESH.
    """

    logging.info("Opening input file: %s", input_file)
    ds = xr.open_dataset(input_file)

    logging.info("Opening drainage database: %s", drainage_db_file)
    drainage_ds = xr.open_dataset(drainage_db_file)

    # ------------------------------------------------------------------
    # Dimension / coordinate handling
    # ------------------------------------------------------------------
    # Rename the stations dimension to subbasin
    ds = ds.rename_dims({"stations": "subbasin"})

    # Extract subbasin IDs from station_id (assumed numeric strings)
    station_ids = ds["station_id"].astype(str).str.strip().astype(int).values

    # Determine target subbasin order from Rank field in drainage database
    target_subbasins = drainage_ds["subbasin"].values[
        np.argsort(drainage_ds["Rank"].values)
    ]

    # Map FEWS station IDs to target order
    reorder_idx = [np.where(station_ids == sb)[0][0] for sb in target_subbasins]
    ds = ds.isel(subbasin=reorder_idx)

    # Replace subbasin coordinate with ordered integers from drainage DB
    ds = ds.assign_coords(subbasin=("subbasin", target_subbasins.astype(int)))
    ds["subbasin"].attrs["units"] = "1"

    # ------------------------------------------------------------------
    # Remove variables & tidy coordinate attributes
    # ------------------------------------------------------------------
    ds = ds.drop_vars(["x", "y", "z", "station_names", "station_id"], errors="ignore")

    # Ensure NaN fill values on lat/lon and clean attributes
    for coord in ("lat", "lon"):
        var = ds[coord]
        var.attrs.pop("_FillValue", None)
        var.encoding.pop("_FillValue", None)
        var.attrs.update(
            {
                "standard_name": "latitude" if coord == "lat" else "longitude",
                "units": "degrees_north" if coord == "lat" else "degrees_east",
                "axis": "X" if coord == "lat" else "Y",
                "_FillValue": np.nan,
            }
        )

    # Convert lat/lon from coordinates to regular data variables so CF encoder does
    # NOT automatically declare them as geographical coordinates for every field.
    ds = ds.reset_coords(["lat", "lon"], drop=False)

    # Clean time attributes
    ds["time"].attrs.pop("calendar", None)
    ds["time"].attrs.update(
        {
            "standard_name": "time",
            "long_name": "time",
            "axis": "T",
        }
    )

    # ------------------------------------------------------------------
    # Data‑variable adjustments
    # ------------------------------------------------------------------
    for v in list(ds.data_vars):
        # Remove stale "coordinates" attribute if present
        ds[v].attrs.pop("coordinates", None)
        ds[v].encoding.pop("coordinates", None)

        # Ensure dimension order is (subbasin, time)
        if set(ds[v].dims) == {"subbasin", "time"} and ds[v].dims[0] != "subbasin":
            ds[v] = ds[v].transpose("subbasin", "time")

    # ------------------------------------------------------------------
    # Coordinate Reference System variable  (create before ordering)
    # ------------------------------------------------------------------
    if "crs" not in ds:
        ds["crs"] = xr.DataArray(
            1,
            attrs={
                "grid_mapping_name": "latitude_longitude",
                "longitude_of_prime_meridian": 0.0,
                "semi_major_axis": 6378137.0,
                "inverse_flattening": 298.257223563,
                "units": "1",
            },
        )

    # ------------------------------------------------------------------
    # Order variables to match MESH reference ordering
    # ------------------------------------------------------------------
    desired_order = [
        "PRES",  # Surface pressure
        "QA",    # Specific humidity
        "TA",    # Air temperature
        "UV",    # Wind modulus
        "PRE",   # Precipitation rate
        "FSIN",  # Downward solar flux
        "FLIN",  # Incoming infra‑red flux
    ]
    ordered_vars = [v for v in desired_order if v in ds.data_vars] + [
        v for v in ds.data_vars if v not in desired_order and v != "crs"
    ]

    # Re‑index dataset, appending crs at the end
    ds = ds[ordered_vars + ["crs"]]

    # ------------------------------------------------------------------
    # Final scrub of any auto‑added "coordinates" attributes
    # ------------------------------------------------------------------
    for v in ds.data_vars:
        ds[v].attrs.pop("coordinates", None)
        ds[v].encoding.pop("coordinates", None)

    # ------------------------------------------------------------------
    # Encoding
    # ------------------------------------------------------------------
    encoding = {var: {"_FillValue": None} for var in ds.data_vars}
    encoding["time"] = {
        "units": "hours since 1970-01-01 00:00:00",
        "calendar": "proleptic_gregorian",
        "dtype": "int32",
        "_FillValue": None,
    }

    # ------------------------------------------------------------------
    # Coordinate Reference System variable
    # ------------------------------------------------------------------
    ds["crs"] = xr.DataArray(
        0,
        attrs={
            "grid_mapping_name": "latitude_longitude",
            "longitude_of_prime_meridian": 0.0,
            "semi_major_axis": 6378137.0,
            "inverse_flattening": 298.257223563,
            "units": "1",
        },
    )

    # ------------------------------------------------------------------
    # Global attributes
    # ------------------------------------------------------------------
    ds.attrs = {
        "author": "University of Calgary",
        "license": "GNU General Public License v3 (or any later version)",
        "purpose": "Create forcing .nc file for MESH",
        "Conventions": "CF-1.6",
        "history": "Converted using custom Python script",
    }

    # ------------------------------------------------------------------
    # Write file
    # ------------------------------------------------------------------
    logging.info("Writing output file: %s", output_file)
    ds.to_netcdf(output_file, encoding=encoding, unlimited_dims=["time"])
    logging.info("Conversion complete.")


if __name__ == "__main__":

    #if len(sys.argv) != 5:
    #    print("Usage: python script.py <input_file> <output_file> <log_file> <drainage_db_file>")
    #    sys.exit(1)
    from pathlib import Path
    input_nc = Path('.\MESH_FEWS_output.nc')
    output_nc = Path('.\MESH_forcing.nc')
    drainage_db = Path('.\MESH_drainage_database.nc')
    log_file = Path('.\log_test.log')
    #input_nc = sys.argv[1]
    #output_nc = sys.argv[2]
    #log_file = sys.argv[4]
    #drainage_db = sys.argv[3]

    setup_logging(log_file)
    convert_netcdf_format(input_nc, output_nc, drainage_db)
