import xarray as xr
import numpy as np
import logging
import sys
import pandas as pd  # ensure pandas is available for time normalization


def setup_logging(log_file: str) -> None:
    """Configure logging to console and a user-specified file."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )


def convert_netcdf_format(input_file: str, output_file: str, drainage_db_file: str) -> None:
    """Convert FEWS point-timeseries NetCDF to MESH forcing format.

    * Re-orders the *subbasin* dimension using `Rank` from the drainage database.
    * Drops unnecessary variables and attributes.
    * Ensures data variables have dimensions `(subbasin, time)`.
    * Sets proper `_FillValue`, units and CRS information expected by MESH.
    """

    logging.info("Opening input file: %s", input_file)
    ds = xr.open_dataset(input_file)

    logging.info("Opening drainage database: %s", drainage_db_file)
    drainage_ds = xr.open_dataset(drainage_db_file)

    # ------------------------------------------------------------------
    # Time normalization: ensure exact hourly stamps and include 00:00:00
    # ------------------------------------------------------------------
    t = pd.DatetimeIndex(ds.indexes["time"])

    # If FEWS provided end-of-interval times (01:00..24:00), shift back to start-of-interval
    if (t.minute == 0).all() and (t.second == 0).all() and (t[0].hour == 1 or (t.hour == 0).sum() == 0):
        t = t - pd.Timedelta(hours=1)

    # Snap to whole hours to remove sub-second jitter before encoding
    t = t.round("H")
    ds = ds.assign_coords(time=t)

    # ------------------------------------------------------------------
    # Dimension / coordinate handling
    # ------------------------------------------------------------------
    ds = ds.rename_dims({"stations": "subbasin"})

    station_ids = ds["station_id"].astype(str).str.strip().astype(int).values

    target_subbasins = drainage_ds["subbasin"].values[
        np.argsort(drainage_ds["Rank"].values)
    ]

    reorder_idx = [np.where(station_ids == sb)[0][0] for sb in target_subbasins]
    ds = ds.isel(subbasin=reorder_idx)

    ds = ds.assign_coords(subbasin=("subbasin", target_subbasins.astype(int)))
    ds["subbasin"].attrs["units"] = "1"

    # ------------------------------------------------------------------
    # Remove variables & tidy coordinate attributes
    # ------------------------------------------------------------------
    ds = ds.drop_vars(["x", "y", "z", "station_names", "station_id"], errors="ignore")

    for coord in ("lat", "lon"):
        var = ds[coord]
        var.attrs.pop("_FillValue", None)
        var.encoding.pop("_FillValue", None)
        var.attrs.update(
            {
                "standard_name": "latitude" if coord == "lat" else "longitude",
                "units": "degrees_north" if coord == "lat" else "degrees_east",
                "axis": "X" if coord == "lat" else "Y",
                "_FillValue": np.nan,
            }
        )

    ds = ds.reset_coords(["lat", "lon"], drop=False)

    ds["time"].attrs.pop("calendar", None)
    ds["time"].attrs.update(
        {
            "standard_name": "time",
            "long_name": "time",
            "axis": "T",
        }
    )

    # ------------------------------------------------------------------
    # Data-variable adjustments
    # ------------------------------------------------------------------
    for v in list(ds.data_vars):
        ds[v].attrs.pop("coordinates", None)
        ds[v].encoding.pop("coordinates", None)

        if set(ds[v].dims) == {"subbasin", "time"} and ds[v].dims[0] != "subbasin":
            ds[v] = ds[v].transpose("subbasin", "time")

    # ------------------------------------------------------------------
    # Coordinate Reference System variable  (create before ordering)
    # ------------------------------------------------------------------
    if "crs" not in ds:
        ds["crs"] = xr.DataArray(
            1,
            attrs={
                "grid_mapping_name": "latitude_longitude",
                "longitude_of_prime_meridian": 0.0,
                "semi_major_axis": 6378137.0,
                "inverse_flattening": 298.257223563,
                "units": "1",
            },
        )

    # ------------------------------------------------------------------
    # Order variables to match MESH reference ordering
    # ------------------------------------------------------------------
    desired_order = ["PRES", "QA", "TA", "UV", "PRE", "FSIN", "FLIN"]
    ordered_vars = [v for v in desired_order if v in ds.data_vars] + [
        v for v in ds.data_vars if v not in desired_order and v != "crs"
    ]
    ds = ds[ordered_vars + ["crs"]]

    # ------------------------------------------------------------------
    # Final scrub of any auto-added "coordinates" attributes
    # ------------------------------------------------------------------
    for v in ds.data_vars:
        ds[v].attrs.pop("coordinates", None)
        ds[v].encoding.pop("coordinates", None)

    # ------------------------------------------------------------------
    # Encoding
    # ------------------------------------------------------------------
    encoding = {var: {"_FillValue": None} for var in ds.data_vars}
    encoding["time"] = {
        "units": "hours since 1970-01-01 12:00:00",
        "calendar": "proleptic_gregorian",
        "dtype": "int",   # float64 is allowed in NETCDF4_CLASSIC; avoids int rounding
        "_FillValue": None,
    }

    # ------------------------------------------------------------------
    # Coordinate Reference System variable
    # ------------------------------------------------------------------
    ds["crs"] = xr.DataArray(
            0,
            attrs={
                "grid_mapping_name": "latitude_longitude",
                "longitude_of_prime_meridian": 0.0,
                "semi_major_axis": 6378137.0,
                "inverse_flattening": 298.257223563,
                "units": "1",
            },
    )

    # ------------------------------------------------------------------
    # Global attributes
    # ------------------------------------------------------------------
    ds.attrs = {
        "author": "University of Calgary",
        "license": "GNU General Public License v3 (or any later version)",
        "purpose": "Create forcing .nc file for MESH",
        "Conventions": "CF-1.6",
        "history": "Converted using custom Python script",
    }

    # ------------------------------------------------------------------
    # Write file (NETCDF4_CLASSIC)
    # ------------------------------------------------------------------
    logging.info("Writing output file: %s", output_file)
    ds.to_netcdf(
        output_file,
        encoding=encoding,
        unlimited_dims=["time"],
        engine="netcdf4",
        format="NETCDF4_CLASSIC",
    )
    logging.info("Conversion complete.")


if __name__ == "__main__":

    #if len(sys.argv) != 5:
    #    print("Usage: python script.py <input_file> <output_file> <log_file> <drainage_db_file>")
    #    sys.exit(1)
    from pathlib import Path
    input_nc = Path('.\\MESH_FEWS_output.nc')
    output_nc = Path('.\\MESH_forcing.nc')
    drainage_db = Path('.\\MESH_drainage_database.nc')
    log_file = Path('.\\log_test.log')

    setup_logging(log_file)
    convert_netcdf_format(input_nc, output_nc, drainage_db)
