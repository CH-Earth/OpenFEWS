sa_mesh_153 > screen_output.txt 2>&1
